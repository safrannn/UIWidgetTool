# Manager window structure

## Flow graph

```mermaid
flowchart TD
    S[Settings<br/>WidgetPreviewObjects]
    C[Checkpoint index<br/>Save dir, file watcher]
    L[Level scan<br/>Asset Registry walk]

    S --> B
    C --> B
    L --> B

    B[UIWTManagerListBuilder<br/>Search, sort, edit session → Entries]

    B --> M

    subgraph M [SUIWidgetManager - manager panel tab]
        LP[List panel<br/>Toolbar, header, SUIWTEntryRow rows]
        UP[Utility panel<br/>Actions, details, chat section]
    end

    M --> V[Snapshot viewer tab<br/>Blueprint + snapshot]
    M --> P[Play launcher<br/>PIE with checkpoint]
    M --> W[Settings save<br/>Confirm, rename, note]
```

## Summary

**Host and tabs.** The window is a nomad `SDockTab` spawned by `SpawnManagerTab` in
`Source/UIWidgetToolPluginEditor/Private/Host/UIWidgetToolPluginEditor.cpp`. It owns a
private `FTabManager` with two panel tabs laid out 60/40 horizontally: **UI Widget Tool**
(the manager) and **Snapshot Viewer**. Both manager spawn paths call `MakeManagerWidget()`,
which builds an `SUIWTChatSection`, then the `SUIWidgetManager` with the chat section
injected as `UtilityPanelContent`. The module wires the manager's delegates outward:
`OnSelectionChanged` refreshes the chat and syncs the viewer, `OnOpenSnapshot` loads a file
into the viewer, `OnDesignBlueprintChanged` sets the viewer's design blueprint, and
`OnEntryDeleted` clears the chat state. Closing the nomad tab resets all shared pointers.

**SUIWidgetManager layout** (`Private/Manager/SUIWidgetManager.cpp`, `Construct`). A
vertical `SSplitter` holds two panels, with a footer showing the checkpoint directory and an
"Open Save Directory" button.

- **List panel** — a toolbar (Add, Update/Confirm, Cancel, Delete, Refresh, a Filter combo
  button, and a search box) above an `SListView<FUIWTManagerEntry>` with four sortable
  header columns: Widget, Level, Level Checkpoint, Blueprint. An overlay message appears
  when the search matches nothing.
- **Utility panel** — a fixed-width left column (Play, Snapshot, Blueprint buttons plus the
  selected-entry details: Widget, Level, Level Checkpoint, Note — each an
  `SUIWTNameEditCell` that turns into a text box on double-click) and the injected chat
  section filling the rest.

**Data pipeline.** `RefreshAll()` rebuilds the `FUIWTCheckpointIndex` from the save
directory, points an `FUIWTDirectoryWatcher` at it (debounced, triggers `RefreshList` on
change), runs `UIWTLevelScan` over every preview object's widget package through the Asset
Registry, then calls `RefreshList()`. That hands the settings' `WidgetPreviewObjects`, the
checkpoint index, the scan results, the edit session and the current
`FUIWTManagerListQuery` (search text, search field, sort column, pinned selection) to
`UIWTManagerListBuilder::Build`, which produces the `Entries` array the list view
displays. The selected entry is pinned so it never disappears while typing.

**Rows and cells.** `OnGenerateRow` creates an `SUIWTEntryRow` per entry, passing a raw
pointer back to the manager. Each cell is an `SUIWTCopyableCell` (right-click
Copy/Rename/Duplicate, double-click routing). Rows don't hold editing state; they ask the
manager via `MakePicker`, `IsFieldPickOpen` and `GetEditSession()`.

**Editing model.** Two paths write to settings. A full **edit session**
(`FUIWTEntryEditSession`) begins on Update: the row's Widget and Level cells become
`SUIWTSearchablePicker`s, picks stay pending, and Confirm applies them, saves, and re-runs
the level scan if the widget class changed. Losing selection auto-confirms all editing
entries. A **field pick** is the lightweight alternative: double-clicking a cell opens a
single picker that writes that one field immediately when its menu closes. Checkpoint picks
always assign at once.

**Selection.** `OnListSelectionChanged` stores the entry id and calls
`NotifySelectionChanged`, which compares a signature (entry id, snapshot path, widget
class) against the last notified one so the owner only reloads the viewer when something
actually moved.

**Outputs.** Play builds an `FUIWTPlayRequest` (map, checkpoint sidecar/payload, widget
class) for `UIWTPlayLauncher`. Snapshot fires `OnOpenSnapshot` with the checkpoint's
`.widgetsnapshot`. Rename, note and duplicate actions edit the settings object and save,
and the widget rename also renames the blueprint asset.
